
import React from 'react';
import { InteractionMode } from '../types';

interface HeaderProps {
  mode: InteractionMode;
  setMode: (mode: InteractionMode) => void;
  onClear: () => void;
}

const Header: React.FC<HeaderProps> = ({ mode, setMode, onClear }) => {
  return (
    <header className="p-4 border-b border-rose-100 bg-white/80 backdrop-blur-md flex items-center justify-between sticky top-0 z-10">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-rose-500 flex items-center justify-center text-white shadow-lg shadow-rose-200">
          <span className="text-lg font-bold">Y</span>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-bold text-gray-800 leading-tight">Yuri</h1>
            <button 
              onClick={onClear}
              className="text-[10px] text-gray-400 hover:text-rose-500 transition-colors"
              title="Clear Memory"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
            </button>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <span className="text-xs text-gray-500 font-medium">Active now</span>
          </div>
        </div>
      </div>

      <div className="bg-rose-50 p-1 rounded-xl flex gap-1">
        <button
          onClick={() => setMode(InteractionMode.TEXT)}
          className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
            mode === InteractionMode.TEXT
              ? 'bg-white text-rose-600 shadow-sm'
              : 'text-gray-500 hover:text-rose-400'
          }`}
        >
          Chat
        </button>
        <button
          onClick={() => setMode(InteractionMode.VOICE)}
          className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
            mode === InteractionMode.VOICE
              ? 'bg-white text-rose-600 shadow-sm'
              : 'text-gray-500 hover:text-rose-400'
          }`}
        >
          Voice
        </button>
      </div>
    </header>
  );
};

export default Header;
