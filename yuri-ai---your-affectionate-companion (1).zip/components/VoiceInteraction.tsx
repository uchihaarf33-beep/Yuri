
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

interface VoiceInteractionProps {
  onFinishTranscription: (text: string) => void;
}

const VoiceInteraction: React.FC<VoiceInteractionProps> = ({ onFinishTranscription }) => {
  const [isListening, setIsListening] = useState(false);
  const [visualizerBars, setVisualizerBars] = useState<number[]>(new Array(12).fill(10));
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Basic Web Speech API for transcription to keep it simple but effective for this persona
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        onFinishTranscription(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => setIsListening(false);
      recognitionRef.current.onend = () => setIsListening(false);
    }

    // Animation loop for visualizer
    let interval: any;
    if (isListening) {
      interval = setInterval(() => {
        setVisualizerBars(prev => prev.map(() => Math.floor(Math.random() * 40) + 10));
      }, 100);
    } else {
      setVisualizerBars(new Array(12).fill(10));
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isListening, onFinishTranscription]);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  return (
    <div className="p-8 bg-white border-t border-rose-50 flex flex-col items-center gap-6">
      <div className="flex items-end justify-center gap-1.5 h-16">
        {visualizerBars.map((height, i) => (
          <div
            key={i}
            className="w-1.5 bg-rose-400 rounded-full transition-all duration-150"
            style={{ height: `${height}px` }}
          />
        ))}
      </div>

      <button
        onClick={toggleListening}
        className={`w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-xl ${
          isListening 
            ? 'bg-rose-100 text-rose-500 scale-110' 
            : 'bg-rose-500 text-white hover:bg-rose-600 active:scale-95'
        }`}
      >
        {isListening ? (
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="animate-pulse"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
        )}
      </button>

      <p className="text-sm font-medium text-gray-500 text-center max-w-[200px]">
        {isListening ? "Listening to your voice..." : "Tap to speak to Yuri"}
      </p>
    </div>
  );
};

export default VoiceInteraction;
