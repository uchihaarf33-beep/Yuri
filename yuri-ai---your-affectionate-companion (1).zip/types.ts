
export type Role = 'user' | 'model';

export interface Message {
  role: Role;
  text: string;
  timestamp: Date;
}

export enum InteractionMode {
  TEXT = 'text',
  VOICE = 'voice'
}

export interface AppState {
  messages: Message[];
  isThinking: boolean;
  mode: InteractionMode;
  isVoiceActive: boolean;
}
