
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { GeminiService } from './services/geminiService';
import { Message, InteractionMode } from './types';
import Header from './components/Header';
import ChatWindow from './components/ChatWindow';
import InputArea from './components/InputArea';
import VoiceInteraction from './components/VoiceInteraction';

const STORAGE_KEY = 'yuri_chat_history';

const App: React.FC = () => {
  const gemini = useMemo(() => new GeminiService(), []);
  
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed.map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) }));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
    return [
      {
        role: 'model',
        text: "Um... hey. 👉👈 I was actually thinking about you. I-I mean... I'm ready if you want to talk or need help with something. How was your day? Honestly... tell me everything, okay? I'm listening.",
        timestamp: new Date()
      }
    ];
  });

  const [isThinking, setIsThinking] = useState(false);
  const [mode, setMode] = useState<InteractionMode>(InteractionMode.TEXT);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
  }, [messages]);

  const handleSendMessage = useCallback(async (text: string) => {
    if (!text.trim()) return;

    const userMsg: Message = { role: 'user', text, timestamp: new Date() };
    // We send current history excluding the one we just added to let the service handle state
    const currentHistory = [...messages];
    
    setMessages(prev => [...prev, userMsg]);
    setIsThinking(true);

    let fullResponse = '';
    const tempModelMsg: Message = { role: 'model', text: '', timestamp: new Date() };
    setMessages(prev => [...prev, tempModelMsg]);

    await gemini.sendMessageStream(text, currentHistory, (chunk) => {
      fullResponse += chunk;
      setMessages(prev => {
        const updated = [...prev];
        updated[updated.length - 1] = { ...updated[updated.length - 1], text: fullResponse };
        return updated;
      });
    });

    setIsThinking(false);
  }, [messages, gemini]);

  const clearHistory = () => {
    if (window.confirm("Do you really want to clear our memories? 🥺")) {
      const initial = [{
        role: 'model' as const,
        text: "Um... okay. We're starting fresh. I-I hope we can make new memories together... 👉👈",
        timestamp: new Date()
      }];
      setMessages(initial);
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload(); 
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto bg-white shadow-2xl relative overflow-hidden">
      <Header mode={mode} setMode={setMode} onClear={clearHistory} />
      
      <main className="flex-1 overflow-hidden relative flex flex-col">
        <ChatWindow messages={messages} isThinking={isThinking} />
        
        {mode === InteractionMode.TEXT ? (
          <InputArea onSend={handleSendMessage} disabled={isThinking} />
        ) : (
          <VoiceInteraction onFinishTranscription={handleSendMessage} />
        )}
      </main>

      <div className="absolute top-[-10%] right-[-10%] w-64 h-64 bg-rose-100 rounded-full blur-3xl opacity-50 pointer-events-none" />
      <div className="absolute bottom-[-5%] left-[-5%] w-48 h-48 bg-pink-100 rounded-full blur-3xl opacity-50 pointer-events-none" />
    </div>
  );
};

export default App;
